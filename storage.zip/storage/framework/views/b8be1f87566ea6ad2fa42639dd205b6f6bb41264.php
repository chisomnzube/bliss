<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<?php echo $__env->yieldContent('head'); ?>

<body class="sidebar-menu-collapsed">
  <div class="se-pre-con"></div>
<section>
  <!-- sidebar menu start -->
  <div class="sidebar-menu sticky-sidebar-menu">

    <!-- logo start -->
    <div class="logo">
      <h1><a href="<?php echo e(route('landingpage')); ?>"><?php echo e(config('app.name')); ?></a></h1>
    </div>


    <div class="logo-icon text-center">
      <a href="<?php echo e(route('landingpage')); ?>" title="logo"><img src="assets/images/logo.png" alt="logo-icon"> </a>
    </div>
    <!-- //logo end -->

    <div class="sidebar-menu-inner">

      <!-- sidebar nav start -->
      <ul class="nav nav-pills nav-stacked custom-nav">
        <li class="active"><a href="<?php echo e(route('landingpage')); ?>"><i class="fa fa-tachometer"></i><span> Dashboard</span></a>
        </li>
        <li class="menu-list">
          <a href="#"><i class="fa fa-users"></i>
            <span>Account <i class="lnr lnr-chevron-right"></i></span></a>
          <ul class="sub-menu-list">
            <?php if(auth()->guard()->check()): ?>
            <li><a href="<?php echo e(route('user.index')); ?>">Profile</a> </li>
            <li><a href="<?php echo e(route('personal.edit')); ?>">My PSN Detail</a> </li>
            <li><a href="<?php echo e(route('company.edit')); ?>">My CSN Info</a> </li>
            <li><a href="<?php echo e(route('particulars.edit')); ?>">My Particulars</a> </li>
            <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log out</a> </li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            <?php else: ?>
            <li><a href="<?php echo e(route('personal.login')); ?>">Login</a></li>
            <li><a href="<?php echo e(route('personal.index')); ?>">Register Personal Detail</a></li>
            <li><a href="<?php echo e(route('company.index')); ?>">Register Company Info</a></li>
            <li><a href="<?php echo e(route('particulars.index')); ?>">Register Particulars</a></li>
            
            <?php endif; ?>
          </ul>
        </li>
        
      </ul>
      <!-- //sidebar nav end -->
      <!-- toggle button start -->
      <a class="toggle-btn">
        <i class="fa fa-angle-double-left menu-collapsed__left"><span>Collapse Sidebar</span></i>
        <i class="fa fa-angle-double-right menu-collapsed__right"></i>
      </a>
      <!-- //toggle button end -->
    </div>
  </div>
  <!-- //sidebar menu end -->
  <!-- header-starts -->
  <div class="header sticky-header">


  </div>
  <!-- //header-ends -->








<?php echo $__env->yieldContent('main-content'); ?>
<!-- main content end-->
</section>
  <!--footer section start-->
<footer class="dashboard">
  <p>&copy <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All Rights Reserved | Design by <a href="https://w3layouts.com/" target="_blank"
      class="text-primary">W3layouts.</a></p>
</footer>
<!--footer section end-->
<!-- move top -->
<button onclick="topFunction()" id="movetop" class="bg-primary" title="Go to top">
  <span class="fa fa-angle-up"></span>
</button>
<?php echo $__env->yieldContent('script'); ?>



</body>

</html>
  <?php /**PATH C:\wamp64\Laravel\bliss\resources\views/layouts/app.blade.php ENDPATH**/ ?>