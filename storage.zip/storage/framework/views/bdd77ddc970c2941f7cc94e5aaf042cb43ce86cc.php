<?php $__env->startSection('head'); ?>

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>CSN Search | <?php echo e(config('app.name')); ?></title>

  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-starter.css">

  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900&display=swap" rel="stylesheet">
</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
  <!-- main content start -->
<div class="main-content" style="background-image: url(<?php echo e(asset('assets/images/techy2.jpg')); ?>);">

  <!-- content -->
  <div class="container-fluid content-top-gap">

    <nav aria-label="breadcrumb">
      <ol class="breadcrumb my-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('landingpage')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">CSN search</li>
      </ol>
    </nav>
    <?php if(auth()->guard()->check()): ?>
      <div class="welcome-msg pt-3 pb-4">
        <h1>Hi <span class="text-primary"><?php echo e(auth()->user()->name); ?></span>, Welcome back</h1>
        
      </div>
    <?php endif; ?>
    <div class="row">
      <div class="col">
        <h3>Company Info</h3>
        <p><b>Industry: <?php echo e($csn->industry); ?></b></p>
        <p><b>Type od Company: <?php echo e($csn->toc); ?></b></p>
        <p><b>Company name: <?php echo e($csn->company_name); ?></b></p>
        <p><b>Parent Company<?php echo e($csn->parent_company); ?></b></p>
        <p><b>Office Address: <?php echo e($csn->office_address); ?></b></p>
        <p><b>Branches: <?php echo e($csn->branches); ?></b></p>
        <p><b>Year of establishment: <?php echo e($csn->yoe); ?></b></p>
        <p><b>Date of Incorporation: <?php echo e($csn->doi); ?></b></p>
        <p><b>No of employees: <?php echo e($csn->employees); ?></b></p>
        <p><b>Others: <?php echo e($csn->others); ?></b></p>
        <br>
        <h3>Registration Info</h3>
        <p><b>Registration date: <?php echo e($csn->reg_date); ?></b></p>
        <p><b>Name: <?php echo e($csn->name); ?></b></p>
        <p><b>Address: <?php echo e($csn->address); ?></b></p>
        <p><b>ID Number: <?php echo e($csn->id_number); ?></b></p>
        <p><b>ID type: <?php echo e($csn->id_type); ?></b></p>
        <p><b>Position: <?php echo e($csn->position); ?></b></p>
        <p><b>Security Status<?php echo e($csn->security_status); ?></b></p>
        <p><b>Rating: <?php echo e($csn->rating); ?></b></p>
        
      </div>
      <div class="col">
        <h3>Business Info</h3>
        <p><b>Market: <?php echo e($csn->market); ?></b></p>
        <p><b>Traded as: <?php echo e($csn->traded_as); ?></b></p>
        <p><b>Stock price: <?php echo e($csn->stock_price); ?></b></p>
        <p><b>ISIN: <?php echo e($csn->isin); ?></b></p>
        <p><b>RC Number: <?php echo e($csn->rc); ?></b></p>
        <p><b>Founded: <?php echo e($csn->founded); ?></b></p>
        <p><b>Founder: <?php echo e($csn->founder); ?></b></p>
        <p><b>Area served: <?php echo e($csn->area_served); ?></b></p>
        <p><b>Key people: <?php echo e($csn->key_people); ?></b></p>
        <p><b>Products: <?php echo e($csn->products); ?></b></p>
        <p><b>Revenue: <?php echo e($csn->revenue); ?></b></p>
        <p><b>Authorized share capital: <?php echo e($csn->asc); ?></b></p>
        <p><b>Market Cap: <?php echo e($csn->market_cap); ?></b></p>
        <p><b>Total Asset: <?php echo e($csn->asset); ?></b></p>
        <p><b>Total equity: <?php echo e($csn->equity); ?></b></p>
        <p><b>Operating Income: <?php echo e($csn->operating_income); ?></b></p>
        <p><b>Net Income: <?php echo e($csn->net_income); ?></b></p>
        <p><b>Subsidiaries: <?php echo e($csn->subsidiary); ?></b></p>
        <p><b>Website: <?php echo e($csn->website); ?></b></p>
        <p><b>Email: <?php echo e($csn->email); ?></b></p>
        <p><b>Phone number: <?php echo e($csn->phone); ?></b></p>

        
      </div>
    </div>



  </div>
  <!-- //content -->
</div>
<!-- main content end-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction()
  };

  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("movetop").style.display = "block";
    } else {
      document.getElementById("movetop").style.display = "none";
    }
  }

  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
</script>
<!-- /move top -->


<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/jquery-1.10.2.min.js"></script>

<!-- chart js -->
<script src="assets/js/Chart.min.js"></script>
<script src="assets/js/utils.js"></script>
<!-- //chart js -->

<!-- Different scripts of charts.  Ex.Barchart, Linechart -->
<script src="assets/js/bar.js"></script>
<script src="assets/js/linechart.js"></script>
<!-- //Different scripts of charts.  Ex.Barchart, Linechart -->


<script src="assets/js/jquery.nicescroll.js"></script>
<script src="assets/js/scripts.js"></script>

<!-- close script -->
<script>
  var closebtns = document.getElementsByClassName("close-grid");
  var i;

  for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function () {
      this.parentElement.style.display = 'none';
    });
  }
</script>
<!-- //close script -->

<!-- disable body scroll when navbar is in active -->
<script>
  $(function () {
    $('.sidebar-menu-collapsed').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- disable body scroll when navbar is in active -->

 <!-- loading-gif Js -->
 <script src="assets/js/modernizr.js"></script>
 <script>
     $(window).load(function () {
         // Animate loader off screen
         $(".se-pre-con").fadeOut("slow");;
     });
 </script>
 <!--// loading-gif Js -->

<!-- Bootstrap Core JavaScript -->
<script src="assets/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\bliss\resources\views/company-search.blade.php ENDPATH**/ ?>