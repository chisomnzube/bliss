<?php $__env->startSection('head'); ?>

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title><?php echo e(config('app.name')); ?></title>

  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-starter.css">

  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900&display=swap" rel="stylesheet">
</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
  <!-- main content start -->
<div class="main-content" style="background-image: url(<?php echo e(asset('assets/images/techy2.jpg')); ?>);">

  <!-- content -->
  <div class="container-fluid content-top-gap">

    <nav aria-label="breadcrumb">
      <ol class="breadcrumb my-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('landingpage')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
      </ol>
    </nav>
    <?php if(auth()->guard()->check()): ?>
      <div class="welcome-msg pt-3 pb-4">
        <h1>Hi <span class="text-primary"><?php echo e(auth()->user()->name); ?></span>, Welcome back</h1>
        
      </div>
    <?php endif; ?>
    <div class="row">
      <div class="col">
        <h3>Passport</h3>
        <img src="<?php echo e(asset('storage/'.$psn->passport)); ?>" width="150">
        <hr>
        <h3>Personal Detail:</h3>
        <p><b>Title: <?php echo e($psn->title); ?></b></p>
        <p><b>First name: <?php echo e($psn->fname); ?></b></p>
        <p><b>Last Name: <?php echo e($psn->lname); ?></b></p>
        <p><b>Middle Name: <?php echo e($psn->mname); ?></b></p>
        <p><b>Median NAme: <?php echo e($psn->median_name); ?></b></p>
        <p><b>Marital Status: <?php echo e($psn->marital_status); ?></b></p>
        <p><b>Gender: <?php echo e($psn->gender); ?></b></p>
        <p><b>Dateof Birth: <?php echo e($psn->dob); ?></b></p>
        <p><b>Place of Birth: <?php echo e($psn->pob); ?></b></p>
        <p><b>State: <?php echo e($psn->state); ?></b></p>
        <p><b>LGA: <?php echo e($psn->lga); ?></b></p>
        <p><b>CITY: <?php echo e($psn->city); ?></b></p>
        <p><b>Nationality: <?php echo e($psn->nationality); ?></b></p>
        <p><b>Resident Status: <?php echo e($psn->residence_status); ?></b></p>
        <hr>
        <h3>Other Details</h3>
        <p><b>Native Language: <?php echo e($psn->native_lang); ?></b></p>
        <p><b>Other Language: <?php echo e($psn->other_lang); ?></b></p>
        <p><b>Religion: <?php echo e($psn->religion); ?></b></p>
        <p><b>Education Level: <?php echo e($psn->education); ?></b></p>
        <p><b>Employment status: <?php echo e($psn->employment_status); ?></b></p>
        <p><b>Company: <?php echo e($psn->company); ?></b></p>
        <p><b>Company address: <?php echo e($psn->company_address); ?></b></p>
        <p><b>Job title: <?php echo e($psn->job_title); ?></b></p>
        <p><b>Year of appointment: <?php echo e($psn->yoa); ?></b></p>
        <p><b>Emergency contact person: <?php echo e($psn->ecp); ?></b></p>
        <p><b>ECP Address: <?php echo e($psn->ecp_address); ?></b></p>
        <p><b>ECP phone: <?php echo e($psn->ecp_phone); ?></b></p>
        <p><b>ECP relationship: <?php echo e($psn->relationship); ?></b></p>
        
        <p><b>Health Status: <?php echo e($psn->health_status); ?></b></p>
        <p><b>Security Status: <?php echo e($psn->security_status); ?></b></p>
      </div>
      <div class="col">

        <h3>Contact Info</h3>
        <p><b>Phone Number: <?php echo e($psn->phone); ?></b></p>
        <p><b>Email: <?php echo e($psn->email); ?></b></p>
        <hr>
        <h3>Social Sites</h3>
        <p><b>Facebook: <?php echo e($psn->facebook); ?></b></p>
        <p><b>Twitter: <?php echo e($psn->twitter); ?></b></p>
        <p><b>Linkedin: <?php echo e($psn->linkedin); ?></b></p>
        <p><b>Instagram: <?php echo e($psn->instagram); ?></b></p>
        <hr>
        <h3>Identification</h3>
        <p><b>ID type: <?php echo e($psn->id_type); ?></b></p>
        <p><b>ID Number: <?php echo e($psn->id_number); ?></b></p>
        <hr>
        <h3>Financial Institutions</h3>
        <p><b>Bank name: <?php echo e($psn->bank_name); ?></b></p>
        <p><b>Bank Address: <?php echo e($psn->bank_address); ?></b></p>
        <p><b>Sort Code: <?php echo e($psn->sort_code); ?></b></p>
        <p><b>Account type: <?php echo e($psn->account_type); ?></b></p>
        <p><b>Account number<?php echo e($psn->account_number); ?></b></p>
        <p><b>Tax ID: <?php echo e($psn->tax); ?></p>
      </div>
    </div>



  </div>
  <!-- //content -->
</div>
<!-- main content end-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction()
  };

  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("movetop").style.display = "block";
    } else {
      document.getElementById("movetop").style.display = "none";
    }
  }

  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
</script>
<!-- /move top -->


<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/jquery-1.10.2.min.js"></script>

<!-- chart js -->
<script src="assets/js/Chart.min.js"></script>
<script src="assets/js/utils.js"></script>
<!-- //chart js -->

<!-- Different scripts of charts.  Ex.Barchart, Linechart -->
<script src="assets/js/bar.js"></script>
<script src="assets/js/linechart.js"></script>
<!-- //Different scripts of charts.  Ex.Barchart, Linechart -->


<script src="assets/js/jquery.nicescroll.js"></script>
<script src="assets/js/scripts.js"></script>

<!-- close script -->
<script>
  var closebtns = document.getElementsByClassName("close-grid");
  var i;

  for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function () {
      this.parentElement.style.display = 'none';
    });
  }
</script>
<!-- //close script -->

<!-- disable body scroll when navbar is in active -->
<script>
  $(function () {
    $('.sidebar-menu-collapsed').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- disable body scroll when navbar is in active -->

 <!-- loading-gif Js -->
 <script src="assets/js/modernizr.js"></script>
 <script>
     $(window).load(function () {
         // Animate loader off screen
         $(".se-pre-con").fadeOut("slow");;
     });
 </script>
 <!--// loading-gif Js -->

<!-- Bootstrap Core JavaScript -->
<script src="assets/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\bliss\resources\views/personal-search.blade.php ENDPATH**/ ?>